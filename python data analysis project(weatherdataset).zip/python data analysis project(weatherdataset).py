#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


import numpy as np
import seaborn as sns


# In[18]:


w_dataset=pd.read_csv("weatherHistory.csv.zip")


# In[19]:


w_dataset


# In[23]:


w_dataset.head(10)


# In[24]:


w_dataset.tail(10)


# In[25]:


w_dataset.shape


# In[26]:


w_dataset.index


# In[27]:


w_dataset.columns


# In[28]:


w_dataset.dtypes


# In[32]:





# In[33]:


w_dataset["Summary"].unique()


# In[36]:


w_dataset.nunique()


# In[37]:


w_dataset.count


# In[38]:


w_dataset["Summary"].value_counts()


# In[39]:


w_dataset.info()


# In[41]:


w_dataset.head(2)


# In[42]:


w_dataset.nunique()


# In[49]:


w_dataset["Summary"].nunique()


# In[50]:


w_dataset["Summary"].unique()


# In[53]:


# value_counts()
w_dataset.Summary.value_counts()


# In[54]:


# Filtering
#w_dataset.head(2)
w_dataset[w_dataset.Summary == "Clear"]


# In[55]:


# GROUPBY()
#w_dataset.head(2)
w_dataset.groupby("Summary").get_group("Clear")


# # Q)3.Find the number of times when the wind speed was exactly 14.1197 km/h'.
# 

# In[56]:


w_dataset.head(2)


# In[63]:


w_dataset[w_dataset["Wind Speed (km/h)"] == 14.1197]


# # Find out the null Values in the data.

# In[65]:


w_dataset.isnull().sum()


# In[ ]:





# # Rename the column name "Daily Summary" of dataframe to "Weather Condition".

# In[67]:


w_dataset.head(2)


# In[70]:


w_dataset.rename(columns = {"Daily Summary" : "Weather Condition"})


# In[71]:


w_dataset.head(2)


# # what is the mean  and std"Humadity"?

# In[79]:


w_dataset.Humidity.mean()


# In[80]:


w_dataset.Humidity.std()


# # what is the Variance of "Humadity"?

# In[84]:


w_dataset.Humidity.var()


# # Find all instances when "Drizzle"was recorded.

# In[86]:


# value_count()
w_dataset.head(2)


# In[89]:


w_dataset.Summary.value_counts()


# In[95]:


#filtering
w_dataset[w_dataset["Summary"] == ('Breezy')]


# In[94]:


#str.contains
w_dataset[w_dataset["Summary"].str.contains("Breezy")]



# # Find all instances when "Wind speed is above 14.1197" and  "visibility (km)" is	15.8263

# In[97]:


w_dataset.head(2)


# In[105]:


w_dataset[(w_dataset["Wind Speed (km/h)"] > 14.11) & (w_dataset["Visibility (km)"] == 15.82)]


# In[ ]:





# In[ ]:




